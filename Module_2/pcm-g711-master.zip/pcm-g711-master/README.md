pcm-g711
========

An ANSI C library for encoding/decoding using the A-law and u-Law.

>About pcm-g711:<br/>
>http://dystopiancode.blogspot.ro/2012/02/pcm-law-and-u-law-companding-algorithms.html<br/>